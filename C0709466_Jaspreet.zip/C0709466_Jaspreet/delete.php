
<?php
include "MyDatabase.php"; 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "C0709466_JaspreetKaur";
// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
else{
echo "";
}

//var_dump($_POST);

if(isset($_POST['Delete']))
  {
	  $id = $_GET['id'];

$query  = "DELETE FROM employee_m WHERE Employee_ID='$id';";
		//$sql = mysql_query($query,$conn);
		$sql = $conn->query($query);
		
	//echo "$query";
			
			
			
	//echo $query;
		
    if($sql)
    {
      echo "Record Added Successfully";
        //<script>
           // alert('Employee had been successfully added.');
            
        //</script>
		
		header("Location: payroll.php");
      
    }

    else
    {
       echo "error";
       // <script>
           // alert('Invalid.');
            
       // </script>
       
    }
  }
?>